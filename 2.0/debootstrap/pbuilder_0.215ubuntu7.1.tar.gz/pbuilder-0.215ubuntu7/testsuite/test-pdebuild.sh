# try this ?
pdebuild --configfile ~/.pbuilderrc --buildsourceroot fakeroot --pbuilderroot sudo --buildresult /var/tmp/test-results --auto-debsign $*