#!/bin/sh

set -e
dpkg -l 
